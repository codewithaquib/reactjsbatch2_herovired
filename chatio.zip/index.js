const express = require('express');
const app = express();
const server = require('http').createServer(app);
var io = require('socket.io')(server);

app.get('/', (req,res)=>{
    res.sendFile(__dirname+'/pages/index.html');
});

io.on('connection', (socket)=>{
    console.log('New user connected!');
    let name;

    socket.on('new user', (username)=>{
        name = username;
        var str = name + ' joined!';
        io.emit('new message', str);
    });

    socket.on('new message', (message)=>{
        var str = name + ' : '+message;
        socket.broadcast.emit('new message', str);
    });

    socket.on('disconnect', ()=>{
        var str = name + ' left';
        io.emit('new message', str);
    });
});


server.listen(3000,()=>{
    console.log("Started!");
});